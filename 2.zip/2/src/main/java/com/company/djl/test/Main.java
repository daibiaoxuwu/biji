package com.company.djl.test;

import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFParagraph;
import org.apache.poi.xwpf.usermodel.XWPFRun;

import java.io.IOException;
import java.net.URISyntaxException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

class WordDocument{
}

public class Main {
    static WordDocument wordDocument;

    public String convertTextFileToString(String fileName) {
        try {
            Stream<String> stream = Files.lines(Paths.get(ClassLoader.getSystemResource(fileName).toURI()));
            return stream.collect(Collectors.joining(" "));
        } catch (IOException | URISyntaxException e) {
            return null;
        }
    }
    public static void main(String[] args){
        try {
            Path msWordPath = Paths.get("D:\\prog10\\Desktop\\2.docx");
            XWPFDocument document = new XWPFDocument(Files.newInputStream(msWordPath));
            List<XWPFParagraph> paragraphs = document.getParagraphs();
            XWPFParagraph title = paragraphs.get(0);
            XWPFRun titleRun = title.getRuns().get(0);
            System.out.println(title.getText());

            document.close();
        } catch (IOException e) {
            return;
        }
    }


}
